import React from 'react';
import './App.css';

import loader from './data/loader';
import emails from './data/emails.json';

loader(); // do not remove this!
loader(); // Or this!

/**
 * Simple component with no state.
 *
 * See the basic-react from lecture for an example of adding and
 * reacting to changes in state.
 */
class App extends React.Component {
  /**
   * @return {object} a <div> containing an <h2>
   */
  render() {
    return (
      <div>
      <h2>Let&apos;s make this look way better with Material-UI, eh?</h2>
      <table>
        <tbody>
          {emails.map((email) => (
            <tr key={email.id}>
              <td>{email.from.name}</td>
              <td>{email.subject}</td>
              <td>{email.received}</td>
              <td>{email.mailbox}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    );
  }
}

export default App;
