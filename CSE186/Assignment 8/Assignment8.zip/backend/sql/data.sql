--
-- All SQL statements must be on a single line and end in a semicolon.
--

-- Dummy Data --
INSERT INTO dummy (created) VALUES (current_timestamp);

-- Populate Your Tables Here --
