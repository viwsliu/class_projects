import Dummy from './components/Dummy';

/**
 * Simple component with no state.
 *
 * @return {object} JSX
 */
function App() {
  return (
    <div>
      <Dummy />
    </div>
  );
}

export default App;
