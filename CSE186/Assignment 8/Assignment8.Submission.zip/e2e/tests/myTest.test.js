//login

//check if mailbox exists

//go to different mailboxes

//search

//compose